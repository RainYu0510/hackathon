extends PlayerBase

